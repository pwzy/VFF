import torch
import torch.nn as nn
from torch.nn import functional as F


class Learner(nn.Module):
    def __init__(self, nfeat=2048, nclass=1, dropout_rate=0.8, k_size=5):
        super(Learner, self).__init__()

        # self.fc0 = nn.Linear(nfeat, 512)

        self.fc0 = nn.Sequential(
            nn.Linear(nfeat, 512),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )

        self.conv = nn.Conv1d(in_channels=512,out_channels=512,kernel_size=k_size)

        # self.fc1_1 = nn.Linear(512, 128)
        # self.fc1_2 = nn.Linear(128, 1)

        self.classifier1 = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

        
        # self.fc2_1 = nn.Linear(512, 128)
        # self.fc2_2 = nn.Linear(128, 128)

        self.classifier2 = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 128)
        )

        self.dropout_rate = dropout_rate
        self.k_size = k_size
        # if self.training:
        #     self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.fill_(1)
                # m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()

    def forward(self, input, is_train=True):

        if is_train:
        
            # fea = F.relu(self.fc0(input))
            # fea = F.dropout(fea, self.dropout_rate, training=self.training)
            fea = self.fc0(input)

            fea_anomaly, fea_normal = fea[:, :fea.shape[1] // 2, :], fea[:, fea.shape[1] // 2:, :]
            # temporal
            old_fea = fea_anomaly.permute(0,2,1) 
            old_fea = torch.nn.functional.pad(old_fea, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea = self.conv(old_fea)
            new_fea = new_fea.permute(0,2,1)  # [30, 32, 512]

            old_fea_assist = fea_normal.permute(0,2,1) 
            old_fea_assist = torch.nn.functional.pad(old_fea_assist, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea_assist = self.conv(old_fea_assist)
            new_fea_assist = new_fea_assist.permute(0,2,1)

            # Merge Model

            # new_fea = torch.stack([new_fea, new_fea_assist]).mean(0)

            atten_map = self.adj_similarity(new_fea, new_fea_assist) # [30,32,32]
            diag = torch.diagonal(atten_map, dim1=-1, dim2=-2) # [30, 32]
            diag = diag.reshape(30,32,1)

            new_fea = new_fea * diag +  new_fea_assist 




            # semantic
            # x = F.relu(self.fc1_1(new_fea))
            # x = F.dropout(x, self.dropout_rate, training=self.training)
            # x = torch.sigmoid(self.fc1_2(x))
            x = self.classifier1(new_fea)
            # dynamic
            # new_fea = F.relu(self.fc2_1(new_fea))
            # new_fea = F.dropout(new_fea, self.dropout_rate, training=self.training)
            # new_fea = self.fc2_2(new_fea)
            new_fea = self.classifier2(new_fea)

            return x, new_fea
        
        else:  # test situation
            
            # fea = F.relu(self.fc0(input))
            # fea = F.dropout(fea, self.dropout_rate, training=self.training)

            fea = self.fc0(input)
            
            # temporal
            old_fea = fea.permute(0,2,1) 
            old_fea = torch.nn.functional.pad(old_fea, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea = self.conv(old_fea)
            new_fea = new_fea.permute(0,2,1)

            # semantic
            # x = F.relu(self.fc1_1(new_fea))
            # x = F.dropout(x, self.dropout_rate, training=self.training)
            # x = torch.sigmoid(self.fc1_2(x))
            x = self.classifier1(new_fea)
            # dynamic
            # new_fea = F.relu(self.fc2_1(new_fea))
            # new_fea = F.dropout(new_fea, self.dropout_rate, training=self.training)
            # new_fea = self.fc2_2(new_fea)
            new_fea = self.classifier2(new_fea)

            return x, new_fea

    # def adj_similarity(self, x):
    #     soft = nn.Softmax(1)
    #     x2 = x.matmul(x.permute(0,2,1)) # B*T*T
    #     x_norm = torch.norm(x, p=2, dim=2, keepdim=True)  # B*T*1
    #     x_norm_x = x_norm.matmul(x_norm.permute(0,2,1))
    #     x2 = x2/(x_norm_x+1e-20)
    #     output = torch.zeros_like(x2)

    #     for i in range(x.shape[0]):
    #         tmp = x2[i]
    #         adj2 = tmp
    #         adj2 = F.threshold(adj2, 0.7, 0)
    #         adj2 = soft(adj2)
    #         output[i] = adj2

    #     return output

    def adj_similarity(self, x, y):
        soft = nn.Softmax(1)
        x2 = x.matmul(y.permute(0,2,1)) # B*T*T
        x_norm = torch.norm(x, p=2, dim=2, keepdim=True)  # B*T*1
        y_norm = torch.norm(y, p=2, dim=2, keepdim=True)  # B*T*1
        x_norm_x = x_norm.matmul(y_norm.permute(0,2,1))
        x2 = x2/(x_norm_x+1e-20)
        # output = torch.zeros_like(x2)

        # for i in range(x.shape[0]):
        #     tmp = x2[i]
        #     adj2 = tmp
        #     adj2 = F.threshold(adj2, 0.7, 0)
        #     adj2 = soft(adj2)
        #     output[i] = adj2

        return x2

 