import torch.utils.data as data
import numpy as np
import torch
from torch.utils.data import DataLoader
torch.set_default_tensor_type('torch.FloatTensor')

def process_feat(feat, length):
    new_feat = np.zeros((length, feat.shape[1])).astype(np.float32)
    
    r = np.linspace(0, len(feat), length+1, dtype=np.int64)
    for i in range(length):
        if r[i]!=r[i+1]:
            new_feat[i,:] = np.mean(feat[r[i]:r[i+1],:], 0)
        else:
            new_feat[i,:] = feat[r[i],:]
    return new_feat

class Dataset(data.Dataset):
    def __init__(self, is_normal=True, test_mode=False):
        self.is_normal = is_normal
        self.dataset = 'shanghai'
        if self.dataset == 'shanghai':
            if test_mode:
                self.rgb_list_file = 'list/shanghai-i3d-test-10crop.list'
            else:
                self.rgb_list_file = 'list/shanghai-i3d-train-10crop.list'
        else:
            if test_mode:
                self.rgb_list_file = 'list/ucf-i3d-test.list'
            else:
                self.rgb_list_file = 'list/ucf-i3d.list'

        self.test_mode = test_mode
        self._parse_list()
        self.num_frame = 0


    def _parse_list(self):
        self.list = list(open(self.rgb_list_file))
        if self.test_mode is False:  # 如果为test_mode则跳过正常与异常视频类别的判断
            if self.dataset == 'shanghai':
                if self.is_normal:               # 判断为正常视频
                    self.list = self.list[63:]   # 175  复制最后14个变为   189
                    self.list = self.list + self.list[-14:]
                    self.list = self.list[:-9]   # 删除最后9个便于batch的操作 共180 个数据

                    # print('normal list for shanghai tech')
                    # print(self.list)
                else:                            # 判断为异常视频
                    self.list = self.list[:63]  
                    self.list = self.list * 3    # 复制3次后成为      189
                    self.list = self.list[:-9]   # 删除最后9个便于batch的操作 共180 个数据
                    # print('abnormal list for shanghai tech')
                    # print(self.list)

            elif self.dataset == 'ucf':
                if self.is_normal:
                    self.list = self.list[810:]
                    # print('normal list for ucf')
                    # print(self.list)
                else:
                    self.list = self.list[:810]
                    # print('abnormal list for ucf')
                    # print(self.list)

    def __getitem__(self, index):

        label = self.get_label()  # get video level label 0/1
        features = np.load(self.list[index].strip('\n'), allow_pickle=True)
        features = np.array(features, dtype=np.float32)

        if self.test_mode:
            return features
        else:
            # process 10-cropped snippet feature
            features = features.transpose(1, 0, 2)  # [10, B, T, F]
            divided_features = []
            for feature in features:
                feature = process_feat(feature, 32)  # divide a video into 32 segments
                divided_features.append(feature)
            divided_features = np.array(divided_features, dtype=np.float32)

            return divided_features#, label

    def get_label(self):

        if self.is_normal:
            label = torch.tensor(0.0)
        else:
            label = torch.tensor(1.0)

        return label

    def __len__(self):
        return len(self.list)

    def get_num_frames(self):
        return self.num_frame
    
if __name__ == "__main__":

    # 训练 异常
    dataset = Dataset(test_mode=False, is_normal=False)
    # divided_features, label = dataset.__getitem__(0)
    # print(divided_features, label)
    print(len(dataset))

    # 训练 正常
    # dataset = Dataset(test_mode=False, is_normal=True)
    # divided_features, label = dataset.__getitem__(0)
    # print(divided_features, label)
    # print(len(dataset))

    # 测试 所有
    # dataset = Dataset(test_mode=True)
    # raw_features = dataset.__getitem__(0)
    # print(len(dataset))
