from torch.utils.data import DataLoader
from model_RTFM import Learner
from loss import *
# from dataset import *
from dataset_RTFM import *
import os
from sklearn import metrics

# 导入数据
normal_train_loader = DataLoader(Dataset(test_mode=False, is_normal=True), batch_size=30, shuffle=True)
normal_train_loade_assist = DataLoader(Dataset(test_mode=False, is_normal=True), batch_size=30, shuffle=True)
anomaly_train_loader = DataLoader(Dataset(test_mode=False, is_normal=False), batch_size=30, shuffle=True) 

test_loader = DataLoader(Dataset(test_mode=True), batch_size=1, shuffle=False)

# 设置设备
device = 'cuda' if torch.cuda.is_available() else 'cpu'

model = Learner().to(device)
# model.load_state_dict(torch.load('./checkpoints/0.8504077947041102_net.pth'))
optimizer = torch.optim.Adagrad(model.parameters(), lr= 0.001, weight_decay=0.00010000000474974513)
# optimizer = torch.optim.Adam(model.parameters(), lr= 0.001, weight_decay=0.0010000000474974513)
scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[25, 50])
criterion = MIL
Rcriterion = torch.nn.MarginRankingLoss(margin=1.0, reduction = 'mean')
Rcriterion = Rcriterion.to(device)

def train(epoch):
    print('\nEpoch: %d' % epoch)
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (normal_inputs, normal_inputs_assist, anomaly_inputs) in enumerate(zip(normal_train_loader, normal_train_loade_assist, anomaly_train_loader)):
        # inputs = torch.cat([anomaly_inputs, normal_inputs], dim=1)
        # batch_size = inputs.shape[0]
        # inputs = inputs.view(-1, inputs.size(-1)).to(device)
        # outputs = model(inputs)
        # loss = criterion(outputs, batch_size)··

        # anomaly_inputs:    torch.Size([30, 10, 32, 2048])
        anomaly_inputs = torch.cat([anomaly_inputs, normal_inputs_assist], dim=2)  # [30, 10, 64, 2048]
        anomaly_inputs = anomaly_inputs.reshape(-1, 64, 2048)                      # [30 * 10, 64, 2048]
        normal_inputs  = torch.cat([normal_inputs, normal_inputs_assist], dim=2)   # [30, 10, 64, 2048]
        normal_inputs = normal_inputs.reshape(-1, 64, 2048)                        # [30 * 10, 64, 2048]  [300, 64, 2048]

        ano_ss, ano_fea = model(anomaly_inputs.to(device))
        nor_ss, nor_fea = model(normal_inputs.to(device))

        ano_cos = torch.cosine_similarity(ano_fea[:,1:], ano_fea[:,:-1], dim=2)
        dynamic_score_ano = 1-ano_cos
        nor_cos = torch.cosine_similarity(nor_fea[:,1:], nor_fea[:,:-1], dim=2)
        dynamic_score_nor = 1-nor_cos
        
        ano_max = torch.max(dynamic_score_ano,1)[0]
        nor_max = torch.max(dynamic_score_nor,1)[0]

        # print(ano_max)
        # print(ano_max.shape )

        # loss_dy = Rcriterion(ano_max, nor_max, pred[:,0])
        loss_dy = Rcriterion(ano_max, nor_max, torch.ones(30).to(device))
        
        semantic_margin_ano = torch.max(ano_ss,1)[0]-torch.min(ano_ss,1)[0]
        semantic_margin_nor = torch.max(nor_ss,1)[0]-torch.min(nor_ss,1)[0]

        # loss_se = Rcriterion(semantic_margin_ano, semantic_margin_nor, pred[:,0])
        loss_se = Rcriterion(semantic_margin_ano, semantic_margin_nor, torch.ones(30, 1).to(device))

        loss_3 = torch.mean(torch.sum(dynamic_score_ano,1))+torch.mean(torch.sum(dynamic_score_nor,1))+torch.mean(torch.sum(ano_ss,1))+torch.mean(torch.sum(nor_ss,1))
        loss_5 = torch.mean(torch.sum((dynamic_score_ano[:,:-1]-dynamic_score_ano[:,1:])**2,1))+torch.mean(torch.sum((ano_ss[:,:-1]-ano_ss[:,1:])**2,1))

        loss = loss_se + loss_dy + loss_3*0.00008+ loss_5*0.00008
        ####################################################################

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
    print('loss = {}', train_loss/len(normal_train_loader))
    # scheduler.step()

def test_abnormal_shanghai_RTFM(epoch):
    model.eval()
    auc = 0
    score_all = np.array([])
    gt_all = np.array([])
    with torch.no_grad():
        for data in test_loader:
            inputs = data  # [1, 28, 10, 2048]
            inputs = inputs.permute(0, 2, 1, 3) # [1, 10, 28, 2048]
            inputs = inputs.reshape(-1, inputs.shape[-2], inputs.shape[-1])
            # inputs = inputs.view(-1, inputs.size(-1)).to(torch.device('cuda'))

            ano_ss, _ = model(inputs.to(device), is_train=False)
            score = ano_ss.reshape(-1, 1)

            # score = model(inputs)
            score = score.cpu().detach().numpy()
            score_list = score.reshape(-1)
            
            score_all = np.concatenate((score_all, score_list), axis=0)  # 最后 score_all: 8932

        score_all = np.repeat(score_all, 16)

        gt_all = np.load('./list/gt-sh.npy')  # 142912
            
        fpr, tpr, thresholds = metrics.roc_curve(gt_all, score_all, pos_label=1)
        auc += metrics.auc(fpr, tpr)

        # print(ano_ss.reshape(-1), nor_ss.reshape(-1))
        print('auc = ', auc)

        # if auc > 0.84:
        #     torch.save(model.state_dict(), './checkpoints/' + str(auc) + '_net.pth')

for epoch in range(0, 200):
    train(epoch)
    test_abnormal_shanghai_RTFM(epoch)

