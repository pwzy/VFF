from torch.utils.data import DataLoader
from model_merge import Learner
from loss import *
from dataset import *
# from dataset_shanghai import *
import os
from sklearn import metrics

normal_train_dataset = Normal_Loader(is_train=1)
normal_train_dataset_assist = Normal_Loader(is_train=1)
normal_test_dataset = Normal_Loader(is_train=0)

anomaly_train_dataset = Anomaly_Loader(is_train=1)
anomaly_test_dataset = Anomaly_Loader(is_train=0)

normal_train_loader = DataLoader(normal_train_dataset, batch_size=30, shuffle=True)
normal_train_loade_assist = DataLoader(normal_train_dataset_assist, batch_size=30, shuffle=True)
normal_test_loader = DataLoader(normal_test_dataset, batch_size=1, shuffle=False)

anomaly_train_loader = DataLoader(anomaly_train_dataset, batch_size=30, shuffle=True) 
anomaly_test_loader = DataLoader(anomaly_test_dataset, batch_size=1, shuffle=False)

device = 'cuda' if torch.cuda.is_available() else 'cpu'

model = Learner().to(device)
model.load_state_dict(torch.load('./checkpoints/0.855_net.pth'))
optimizer = torch.optim.Adagrad(model.parameters(), lr= 0.001, weight_decay=0.00010000000474974513)
# optimizer = torch.optim.Adam(model.parameters(), lr= 0.001, weight_decay=0.0010000000474974513)
scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[25, 50])
criterion = MIL
Rcriterion = torch.nn.MarginRankingLoss(margin=1.0, reduction = 'mean')
Rcriterion = Rcriterion.to(device)

def train(epoch):
    print('\nEpoch: %d' % epoch)
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    fea_list_ano = []
    fea_list_nor = []
    for batch_idx, (normal_inputs, normal_inputs_assist, anomaly_inputs) in enumerate(zip(normal_train_loader, normal_train_loade_assist, anomaly_train_loader)):
        # inputs = torch.cat([anomaly_inputs, normal_inputs], dim=1)
        # batch_size = inputs.shape[0]
        # inputs = inputs.view(-1, inputs.size(-1)).to(device)
        # outputs = model(inputs)
        # loss = criterion(outputs, batch_size)··

        anomaly_inputs = torch.cat([anomaly_inputs, normal_inputs_assist], dim=1)  # [30,64,2048]
        normal_inputs  = torch.cat([normal_inputs, normal_inputs_assist], dim=1)  # [30,64,2048]

        ano_ss, ano_fea = model(anomaly_inputs.to(device))
        nor_ss, nor_fea = model(normal_inputs.to(device))

        fea_list_ano.append(ano_fea.cpu().detach().numpy())
        fea_list_nor.append(nor_fea.cpu().detach().numpy())

        print('batch_idx', batch_idx)
    
    print(len(fea_list_ano))

    np.save('results/fea_list_ano.npy', fea_list_ano)
    np.save('results/fea_list_nor.npy', fea_list_nor)

        # ano_cos = torch.cosine_similarity(ano_fea[:,1:], ano_fea[:,:-1], dim=2)
        # dynamic_score_ano = 1-ano_cos
        # nor_cos = torch.cosine_similarity(nor_fea[:,1:], nor_fea[:,:-1], dim=2)
        # dynamic_score_nor = 1-nor_cos
        
        # ano_max = torch.max(dynamic_score_ano,1)[0]
        # nor_max = torch.max(dynamic_score_nor,1)[0]

        # # print(ano_max)
        # # print(ano_max.shape )

        # # loss_dy = Rcriterion(ano_max, nor_max, pred[:,0])
        # loss_dy = Rcriterion(ano_max, nor_max, torch.ones(30).to(device))
        
        # semantic_margin_ano = torch.max(ano_ss,1)[0]-torch.min(ano_ss,1)[0]
        # semantic_margin_nor = torch.max(nor_ss,1)[0]-torch.min(nor_ss,1)[0]

        # # loss_se = Rcriterion(semantic_margin_ano, semantic_margin_nor, pred[:,0])
        # loss_se = Rcriterion(semantic_margin_ano, semantic_margin_nor, torch.ones(30, 1).to(device))

        # loss_3 = torch.mean(torch.sum(dynamic_score_ano,1))+torch.mean(torch.sum(dynamic_score_nor,1))+torch.mean(torch.sum(ano_ss,1))+torch.mean(torch.sum(nor_ss,1))
        # loss_5 = torch.mean(torch.sum((dynamic_score_ano[:,:-1]-dynamic_score_ano[:,1:])**2,1))+torch.mean(torch.sum((ano_ss[:,:-1]-ano_ss[:,1:])**2,1))

        # loss = loss_se + loss_dy + loss_3*0.00008+ loss_5*0.00008
        # ####################################################################

        # optimizer.zero_grad()
        # loss.backward()
        # optimizer.step()
        # train_loss += loss.item()
    # print('loss = {}', train_loss/len(normal_train_loader))
    # scheduler.step()

def test_abnormal_all(epoch):
    model.eval()
    auc = 0
    score_all = np.array([])
    gt_all = np.array([])
    new_fea_ano_list = []
    new_fea_nor_list = []
    score_record = []
    score_record_gt = []
    with torch.no_grad():
        for data in anomaly_test_loader:
            inputs, gts, frames = data
            # inputs = inputs.view(-1, inputs.size(-1)).to(torch.device('cuda'))

            ano_ss, new_fea_ano = model(inputs.to(device), is_train=False)
            new_fea_ano_list.append(new_fea_ano.squeeze().cpu().numpy())
            score = ano_ss.reshape(-1, 1)

            # score = model(inputs)
            score = score.cpu().detach().numpy()
            score_list = np.zeros(frames[0])
            step = np.round(np.linspace(0, torch.div(frames[0], 16, rounding_mode='floor'), 33))

            for j in range(32):
                score_list[int(step[j])*16:(int(step[j+1]))*16] = score[j]
            score_list[(int(step[32]))*16:] = score[-1]

            gt_list = np.zeros(frames[0])
            for k in range(len(gts)//2):
                s = gts[k*2]
                e = min(gts[k*2+1], frames)
                gt_list[s-1:e] = 1
            
            score_all = np.concatenate((score_all, score_list), axis=0)
            gt_all = np.concatenate((gt_all, gt_list), axis=0)
            score_record.append(score_list)
            score_record_gt.append(gt_list)

        for data2 in normal_test_loader:

            inputs2, gts2, frames2 = data2

            nor_ss, new_fea_nor = model(inputs2.to(device), is_train=False)
            # print(new_fea_nor.squeeze().cpu().numpy().shape)
            new_fea_nor_list.append(new_fea_nor.squeeze().cpu().numpy())

            score2 = nor_ss.reshape(-1, 1)
           
            score2 = score2.cpu().detach().numpy()
            score_list2 = np.zeros(frames2[0])
            step2 = np.round(np.linspace(0, torch.div(frames2[0], 16, rounding_mode='floor'), 33))
            for kk in range(32):
                score_list2[int(step2[kk])*16:(int(step2[kk+1]))*16] = score2[kk]
            score_list2[(int(step2[32]))*16:] = score2[-1]

            gt_list2 = np.zeros(frames2[0])

            score_all = np.concatenate((score_all, score_list2), axis=0)
            gt_all = np.concatenate((gt_all, gt_list2), axis=0)
            score_record.append(score_list2)
            score_record_gt.append(gt_list2)
        
        # np.save('results/new_fea_ano.npy', new_fea_ano_list)
        # np.save('results/new_fea_nor.npy', new_fea_nor_list)
        np.save('results/score.npy', score_record)
        np.save('results/score_gt.npy', score_record_gt)
        print(score_all)
        fpr, tpr, thresholds = metrics.roc_curve(gt_all, score_all, pos_label=1)
        auc += metrics.auc(fpr, tpr)

        # print(ano_ss.reshape(-1), nor_ss.reshape(-1))
        print('auc = ', auc)

        # if auc > 0.84:
        #     torch.save(model.state_dict(), './checkpoints/' + str(auc) + '_net.pth')

for epoch in range(1):
    train(epoch)
    # test_abnormal(epoch)
    # test_abnormal_all(epoch)
    # test_abnormal_shanghai_all(epoch)

