import torch
import torch.nn as nn
from torch.nn import functional as F
from torch import FloatTensor
from torch.nn.parameter import Parameter
import numpy as np
from scipy.spatial.distance import pdist, squareform

# m_seed = 12  # 6, 12
# torch.manual_seed(m_seed)
# torch.cuda.manual_seed_all(m_seed) 
# print('m_seed:', m_seed)

class MixedFusion_Block(nn.Module):
    
    def __init__(self,in_dim=512, out_dim=512):
        super(MixedFusion_Block, self).__init__()
        
        self.layer1 = nn.Sequential(
            nn.Linear(512*3, 512),
            nn.ReLU(),
            nn.Dropout(0.6),
            # nn.Linear(512, 512),
            # nn.ReLU(),
        )
        self.layer2 = nn.Sequential(
            nn.Linear(512*2, 512),
            nn.ReLU(),
            nn.Dropout(0.6),
            # nn.Linear(512, 512),
            # nn.ReLU(),
        )
        # self.reset_parameters()
    
    def reset_parameters(self):
        for m in self.modules():
            if type(m) == nn.Linear:
                torch.nn.init.xavier_uniform_(m.weight)
                m.bias.data.zero_()
        
    def forward(self, x1,x2,xx):
        
        # multi-style fusion
        fusion_sum = torch.add(x1, x2)   # torch.Size([30, 64, 512])
        fusion_mul = torch.mul(x1, x2)  #  torch.Size([30, 64, 512])
        
        modal_in1 = torch.reshape(x1, [x1.shape[0],1,x1.shape[1],x1.shape[2]]) # torch.Size([30, 1, 64, 512])
        modal_in2 = torch.reshape(x2, [x2.shape[0],1,x2.shape[1],x2.shape[2]]) # torch.Size([30, 1, 64, 512])
        modal_cat = torch.cat((modal_in1, modal_in2),dim=1)  # [30, 2, 64, 512]
        
        fusion_max = modal_cat.max(dim=1)[0]  # [30, 64, 512]
        
         
        out_fusion = torch.cat((fusion_sum, fusion_mul, fusion_max),dim=2) # [30, 64, 512 * 3]
        # print(out_fusion.shape)
        
        out1 = self.layer1(out_fusion)
        out2 = self.layer2(torch.cat((out1,xx),dim=2))
        
        return out2

class FeatureFusion(nn.Module):
    def __init__(self, activation=torch.relu, dropout=0.6, size=512):
        super(FeatureFusion, self).__init__()
        self.dropout = dropout
        self.activation = activation
        self.weight0 = Parameter(torch.FloatTensor(size, size))
        self.weight1 = Parameter(torch.FloatTensor(size, size))
        
        torch.nn.init.xavier_uniform_(self.weight0)
        torch.nn.init.xavier_uniform_(self.weight1)
        

    def forward(self, z1, z2):
        # z1 = F.dropout(z1, self.dropout)  # x_ano: [30, 32, 512]
        # z2 = F.dropout(z2, self.dropout)
        
        t = torch.matmul(z1, self.weight0) + torch.matmul(z2, self.weight1) 
        t = F.softmax(t, dim=1)
        t = self.activation(t)
        return t

class GraphConvolution(nn.Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=False, residual=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(FloatTensor(in_features, out_features))

        if bias:
            self.bias = Parameter(FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()
        if not residual:
            self.residual = lambda x: 0
        elif (in_features == out_features):
            self.residual = lambda x: x
        else:
            # self.residual = linear(in_features, out_features)
            self.residual = nn.Conv1d(in_channels=in_features, out_channels=out_features, kernel_size=5, padding=2)
    def reset_parameters(self):
        # stdv = 1. / sqrt(self.weight.size(1))
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            self.bias.data.fill_(0.1)

    def forward(self, input, adj):
        # To support batch operations
        support = input.matmul(self.weight)
        output = adj.matmul(support)

        if self.bias is not None:
            output = output + self.bias
        if self.in_features != self.out_features and self.residual:
            input = input.permute(0,2,1)
            res = self.residual(input)
            res = res.permute(0,2,1)
            output = output + res
        else:
            output = output + self.residual(input)

        return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

class DistanceAdj(nn.Module):

    def __init__(self):
        super(DistanceAdj, self).__init__()
        self.sigma = Parameter(FloatTensor(1))
        self.sigma.data.fill_(0.1)

    def forward(self, batch_size=30, max_seqlen=32):
        # To support batch operations
        self.arith = np.arange(max_seqlen).reshape(-1, 1)
        dist = pdist(self.arith, metric='cityblock').astype(np.float32)
        self.dist = torch.from_numpy(squareform(dist)).to('cuda')
        self.dist = torch.exp(-self.dist / torch.exp(torch.tensor(1.)))
        self.dist = torch.unsqueeze(self.dist, 0).repeat(batch_size, 1, 1).to('cuda')
        return self.dist

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid)
        # self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = nn.Dropout(0.6)

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = self.dropout(x)
        # x = F.relu(self.gc2(x, adj))
        # x = self.dropout(x)
        return x


class Learner(nn.Module):
    def __init__(self, nfeat=2048, nclass=1, dropout_rate=0.6, k_size=5):
        super(Learner, self).__init__()

        # self.fc0 = nn.Linear(nfeat, 512)

        self.fc0 = nn.Sequential(
            nn.Linear(nfeat, 512),
            nn.ReLU(),
            nn.Dropout(dropout_rate)
        )

        self.conv = nn.Conv1d(in_channels=512,out_channels=512,kernel_size=k_size)

        
        self.gc_ano = GraphConvolution(512, 512)
        self.gc_nor = GraphConvolution(512, 512)
        self.disAdj = DistanceAdj()

        self.featfusion = FeatureFusion(size=512)
        # self.fc1_1 = nn.Linear(512, 128)
        # self.fc1_2 = nn.Linear(128, 1)

        self.classifier1 = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

        
        # self.fc2_1 = nn.Linear(512, 128)
        # self.fc2_2 = nn.Linear(128, 128)

        self.classifier2 = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 128)
        )

        self.dropout_rate = dropout_rate
        self.dropout = nn.Dropout(dropout_rate)
        self.k_size = k_size
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.mfb = MixedFusion_Block()
        # if self.training:
            # self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                torch.nn.init.xavier_uniform_(m.weight)
                # n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                # m.weight.data.fill_(1)
                # m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                torch.nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    m.bias.data.zero_()
                # m.weight.data.normal_(0, 0.01)
                # m.bias.data.zero_()

    def forward(self, input, is_train=True):

        if is_train:
        
            # fea = F.relu(self.fc0(input))
            # fea = F.dropout(fea, self.dropout_rate, training=self.training)
            fea = self.fc0(input)  # input: [300, 64, 2048] fea: [300, 64, 512]

            fea_anomaly, fea_normal = fea[:, :fea.shape[1] // 2, :], fea[:, fea.shape[1] // 2:, :]  # [300, 32, 512] [300, 32, 512]
            # temporal
            old_fea = fea_anomaly.permute(0,2,1) 
            old_fea = torch.nn.functional.pad(old_fea, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea = self.conv(old_fea)
            new_fea = new_fea.permute(0,2,1)  # [300, 32, 512]

            old_fea_assist = fea_normal.permute(0,2,1) 
            old_fea_assist = torch.nn.functional.pad(old_fea_assist, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea_assist = self.conv(old_fea_assist)
            new_fea_assist = new_fea_assist.permute(0,2,1)  # [300, 32, 512]

            # Merge Model

            # new_fea = torch.stack([new_fea, new_fea_assist]).mean(0)
            adj_ano, adj_nor = self.adj(new_fea, new_fea_assist)  # adj_ano: [300, 32, 32]

            # 图卷积
            x_ano = F.relu(self.gc_ano(new_fea, adj_ano))
            x_ano = self.dropout(x_ano)  # [300, 32, 512]
            x_nor = F.relu(self.gc_nor(new_fea_assist, adj_nor))
            x_nor = self.dropout(x_nor)  # [300, 32, 512]

            fea_fusion = self.featfusion(x_ano, x_nor)  # [300, 32, 512]

            
            atten_map = self.adj_similarity_fea(new_fea, new_fea_assist) # [30,32,32]
            diag = torch.diagonal(atten_map, dim1=-1, dim2=-2) # [30, 32]
            diag = diag.reshape(300,32,1)

            # new_fea = fea_fusion  # [300, 32, 512]
            new_fea = self.mfb(new_fea_assist, fea_fusion, new_fea)
            new_fea = new_fea.reshape(30, 10, 32, 512).mean(1)  # # [30, 32, 512] # 合并crop-10


            # semantic
            # x = F.relu(self.fc1_1(new_fea))
            # x = F.dropout(x, self.dropout_rate, training=self.training)
            # x = torch.sigmoid(self.fc1_2(x))
            x = self.classifier1(new_fea)
            # dynamic
            # new_fea = F.relu(self.fc2_1(new_fea))
            # new_fea = F.dropout(new_fea, self.dropout_rate, training=self.training)
            # new_fea = self.fc2_2(new_fea)
            new_fea = self.classifier2(new_fea)

            return x, new_fea
        
        else:  # test situation
            
            # fea = F.relu(self.fc0(input))
            # fea = F.dropout(fea, self.dropout_rate, training=self.training)

            fea = self.fc0(input)
            
            # temporal
            old_fea = fea.permute(0,2,1) 
            old_fea = torch.nn.functional.pad(old_fea, (self.k_size//2,self.k_size//2), mode='replicate')
            new_fea = self.conv(old_fea)
            new_fea = new_fea.permute(0,2,1)

            new_fea = new_fea.reshape(1, 10, input.shape[-2], 512).mean(1)  # # [30, 32, 512] # 合并crop-10

            # semantic
            # x = F.relu(self.fc1_1(new_fea))
            # x = F.dropout(x, self.dropout_rate, training=self.training)
            # x = torch.sigmoid(self.fc1_2(x))
            x = self.classifier1(new_fea)
            # dynamic
            # new_fea = F.relu(self.fc2_1(new_fea))
            # new_fea = F.dropout(new_fea, self.dropout_rate, training=self.training)
            # new_fea = self.fc2_2(new_fea)
            new_fea = self.classifier2(new_fea)

            return x, new_fea
    
    def adj(self, x_anomaly, x_normal):
        adj_ano_sim = self.adj_similarity(x_anomaly)
        adj_nor_sim = self.adj_similarity(x_normal)

        adj_dis = self.disAdj(batch_size=x_anomaly.shape[0])

        return adj_ano_sim + adj_dis, adj_nor_sim + adj_dis
        
    def adj_similarity(self, x):
        soft = nn.Softmax(1)
        x2 = x.matmul(x.permute(0,2,1)) # B*T*T
        x_norm = torch.norm(x, p=2, dim=2, keepdim=True)  # B*T*1
        x_norm_x = x_norm.matmul(x_norm.permute(0,2,1))
        x2 = x2/(x_norm_x+1e-20)
        output = torch.zeros_like(x2)

        for i in range(x.shape[0]):
            tmp = x2[i]
            adj2 = tmp
            adj2 = F.threshold(adj2, 0.7, 0)
            adj2 = soft(adj2)
            output[i] = adj2

        return output

    def adj_similarity_fea(self, x, y):
        soft = nn.Softmax(1)
        x2 = x.matmul(y.permute(0,2,1)) # B*T*T
        x_norm = torch.norm(x, p=2, dim=2, keepdim=True)  # B*T*1
        y_norm = torch.norm(y, p=2, dim=2, keepdim=True)  # B*T*1
        x_norm_x = x_norm.matmul(y_norm.permute(0,2,1))
        x2 = x2/(x_norm_x+1e-20)
        # output = torch.zeros_like(x2)

        # for i in range(x.shape[0]):
        #     tmp = x2[i]
        #     adj2 = tmp
        #     adj2 = F.threshold(adj2, 0.7, 0)
        #     adj2 = soft(adj2)
        #     output[i] = adj2

        return x2
    
    def normalize(self, adj):
        """进行领接矩阵的归一化操作"""
        rowsum = torch.sum(adj, dim=2)   # 对行求和，得到度矩阵
        r_inv = torch.pow(rowsum, -1) # 获得D-1对应的对角阵元素
        r_mat_inv = torch.diag_embed(r_inv)   # 构造D-1 
        adj_norm = r_mat_inv.matmul(adj)   # D-1*A  完成归一化操作
        return adj_norm

 