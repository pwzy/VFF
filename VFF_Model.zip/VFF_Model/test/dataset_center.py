import os 
from torch.utils.data import Dataset
import numpy as np
import random
import pickle 

rootPath = '../dataset/shanghai_center/'

def process_feat(feat, length=32):
    new_feat = np.zeros((length, feat.shape[1])).astype(np.float32)
    
    r = np.linspace(0, len(feat), length+1, dtype=np.int64)
    for i in range(length):
        if r[i]!=r[i+1]:
            new_feat[i,:] = np.mean(feat[r[i]:r[i+1],:], 0)
        else:
            new_feat[i,:] = feat[r[i],:]
    return new_feat


path = os.path.join(rootPath, 'train_split.txt')
with open(path, 'r') as f:
    data_list_train = f.readlines()

path = os.path.join(rootPath, 'test_split.txt')
with open(path, 'r') as f:
    data_list_test = f.readlines()

path = os.path.join(rootPath, 'GT/frame_label.pickle')
with open(path, 'rb') as f:
    frame_label = pickle.load(f)

path = os.path.join(rootPath, 'GT/video_label.pickle')
with open(path, 'rb') as f:
    video_label = pickle.load(f)

data_list_train_ano = [x[:-1] for x in data_list_train if len(x) == 8]  # 63   复制3次后成为      189
data_list_train_ano = data_list_train_ano * 3
data_list_train_ano = data_list_train_ano[:-9]                          # 删除最后9个便于batch的操作 共180 个数据

data_list_train_nor = [x[:-1] for x in data_list_train if len(x) == 7]  # 174
data_list_train_nor = data_list_train_nor + ['13_007']                  # 175 增加了最后一个视频 复制最后14个变为   189
data_list_train_nor = data_list_train_nor + data_list_train_nor[-14:]
data_list_train_nor = data_list_train_nor[:-9]                          # 删除最后9个便于batch的操作

data_list_test_ano = [x[:-1] for x in data_list_test if len(x) == 8]  # 44

data_list_test_nor = [x[:-1] for x in data_list_test if len(x) == 7]  # 154
data_list_test_nor = data_list_test_nor + ['13_006']                  # 155 增加最后一个

# frames_dict_normal_videos = np.load(os.path.join(rootPath, 'frames_dict.npy'), allow_pickle=True).item()

class Normal_Loader(Dataset):
    """
    is_train = 1 <- train, 0 <- test
    """
    def __init__(self, is_train=1, path=rootPath):
        super(Normal_Loader, self).__init__()
        self.is_train = is_train
        self.path = path
        if self.is_train == 1:
            self.data_list = data_list_train_nor
        else:
            self.data_list = data_list_test_nor
            
    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        if self.is_train == 1:
            rgb_npy = np.load(os.path.join(self.path, 'features_video/i3d/rgb', self.data_list[idx], 'feature.npy'))
            flow_npy = np.load(os.path.join(self.path, 'features_video/i3d/flow', self.data_list[idx], 'feature.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            concat_npy = process_feat(concat_npy)
            return concat_npy
        else:
            frames = len(frame_label[self.data_list[idx]])
            gts = np.array([0] * frames)
            
            rgb_npy = np.load(os.path.join(self.path, 'features_video/i3d/rgb', self.data_list[idx], 'feature.npy'))
            flow_npy = np.load(os.path.join(self.path, 'features_video/i3d/flow', self.data_list[idx], 'feature.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            return concat_npy, gts, frames

class Anomaly_Loader(Dataset):
    """
    is_train = 1 <- train, 0 <- test
    """
    def __init__(self, is_train=1, path=rootPath):
        super(Anomaly_Loader, self).__init__()
        self.is_train = is_train
        self.path = path
        if self.is_train == 1:
            self.data_list = data_list_train_ano
        else:
            self.data_list = data_list_test_ano

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        if self.is_train == 1:
            rgb_npy = np.load(os.path.join(self.path, 'features_video/i3d/rgb', self.data_list[idx], 'feature.npy'))
            flow_npy = np.load(os.path.join(self.path, 'features_video/i3d/flow', self.data_list[idx], 'feature.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            concat_npy = process_feat(concat_npy)
            return concat_npy
        else:
            frames = len(frame_label[self.data_list[idx]])
            gts = frame_label[self.data_list[idx]]
            
            rgb_npy = np.load(os.path.join(self.path, 'features_video/i3d/rgb', self.data_list[idx], 'feature.npy'))
            flow_npy = np.load(os.path.join(self.path, 'features_video/i3d/flow', self.data_list[idx], 'feature.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            if len(gts) * 16 != frames:
                frames = (frames // 16) * 16
                gts = gts[:frames]
            assert len(gts) == frames, print(self.data_list[idx], len(gts), frames, concat_npy.shape)
            return concat_npy, gts, frames
        
if __name__ == '__main__':
    loader2 = Anomaly_Loader(is_train=0)
    loader2.__getitem__(0)
    print(len(loader2))
    #print(loader[1], loader2[1])