import os 
from torch.utils.data import Dataset
import numpy as np
import random

rootPath = '../dataset/ShanghaiTech/'

path = os.path.join(rootPath, 'splits/train.txt')
with open(path, 'r') as f:
    data_list_train = f.readlines()

path = os.path.join(rootPath, 'splits/test.txt')
with open(path, 'r') as f:
    data_list_test = f.readlines()

data_list_train_ano = [x[:-1] for x in data_list_train if len(x) == 8]  # 63   复制3次后成为      189
data_list_train_ano = data_list_train_ano * 3
data_list_train_ano = data_list_train_ano[:-9]                          # 删除最后9个便于batch的操作 共180 个数据
data_list_train_nor = [x[:-1] for x in data_list_train if len(x) == 7]  # 174
data_list_train_nor = data_list_train_nor + ['13_007']                  # 175 增加了最后一个视频 复制最后14个变为   189
data_list_train_nor = data_list_train_nor + data_list_train_nor[-14:]
data_list_train_nor = data_list_train_nor[:-9]                          # 删除最后9个便于batch的操作

data_list_test_ano = [x[:-1] for x in data_list_test if len(x) == 8]  # 44
data_list_test_nor = [x[:-1] for x in data_list_test if len(x) == 7]  # 154
data_list_test_nor = data_list_test_nor + ['13_006']                  # 155 增加最后一个

frames_dict_normal_videos = np.load(os.path.join(rootPath, 'frames_dict.npy'), allow_pickle=True).item()

class Normal_Loader(Dataset):
    """
    is_train = 1 <- train, 0 <- test
    """
    def __init__(self, is_train=1, path=rootPath):
        super(Normal_Loader, self).__init__()
        self.is_train = is_train
        self.path = path
        if self.is_train == 1:
            self.data_list = data_list_train_nor
        else:
            self.data_list = data_list_test_nor
            
    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        if self.is_train == 1:
            rgb_npy = np.load(os.path.join(self.path+'all_rgbs/Normal_Videos_event', self.data_list[idx]+'.npy'))
            flow_npy = np.load(os.path.join(self.path+'all_flows/Normal_Videos_event', self.data_list[idx]+'.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            return concat_npy
        else:
            frames = frames_dict_normal_videos[self.data_list[idx]+'.avi']
            gts = [0] * frames
            
            rgb_npy = np.load(os.path.join(self.path+'all_rgbs/Normal_Videos_event', self.data_list[idx]+'.npy'))
            flow_npy = np.load(os.path.join(self.path+'all_flows/Normal_Videos_event', self.data_list[idx]+'.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            return concat_npy, gts, frames

class Anomaly_Loader(Dataset):
    """
    is_train = 1 <- train, 0 <- test
    """
    def __init__(self, is_train=1, path=rootPath):
        super(Anomaly_Loader, self).__init__()
        self.is_train = is_train
        self.path = path
        if self.is_train == 1:
            self.data_list = data_list_train_ano
        else:
            self.data_list = data_list_test_ano

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        if self.is_train == 1:
            rgb_npy = np.load(os.path.join(self.path+'all_rgbs/abnormal', self.data_list[idx]+'.npy'))
            flow_npy = np.load(os.path.join(self.path+'all_flows/abnormal', self.data_list[idx]+'.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            return concat_npy
        else:
            gts = np.load(os.path.join(self.path,'testing/test_frame_mask', self.data_list[idx]+'.npy')).tolist()
            frames = len(gts)
            
            rgb_npy = np.load(os.path.join(self.path+'all_rgbs/abnormal', self.data_list[idx]+'.npy'))
            flow_npy = np.load(os.path.join(self.path+'all_flows/abnormal', self.data_list[idx]+'.npy'))
            concat_npy = np.concatenate([rgb_npy, flow_npy], axis=1)
            return concat_npy, gts, frames
        
if __name__ == '__main__':
    loader2 = Anomaly_Loader(is_train=0)
    loader2.__getitem__(0)
    print(len(loader2))
    #print(loader[1], loader2[1])